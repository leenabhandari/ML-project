import pandas
import matplotlib.pyplot as plt

url = 'https://goo.gl/mLmoIz'
names = ['sepal-length', 'sepal-width', 'petal-length', 'petal-width', 'class']
data= pandas.read_csv(url,names=names)
data.describe()
data.groupby('class').size()
data.plot(kind='box', subplots=True, layout=(2,2), sharex=False, sharey=False)
plt.show()
data.hist()
plt.show()