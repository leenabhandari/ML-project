import lifelines
from lifelines.datasets import load_waltons
from lifelines import KaplanMeierFitter
from sklearn.cross_validation import train_test_split

df=load_waltons()
kmf=KaplanMeierFitter()
arr=df.values
X=arr[:,0:1]
Y=arr[:,1]
val_size=0.20
seed=7
X_t,X_v,Y_t,Y_v=train_test_split(X,Y, test_size=val_size , random_state=seed)
kmf.fit(X_t,Y_t,label='test')
ax=kmf.plot()
kmf.fit(X_v,Y_v,label='val')
kmf.plot(ax=ax)
plt.show()
