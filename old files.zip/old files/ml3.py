from sklearn import datasets,neighbors,linear_model
>>> import numpy as np
>>> import matplotlib.pyplot as plt
>>> digits=datasets.load_digits()
>>> X_digits=digits.data
>>> y_digits=digits.target
 X_train=X_digits[: -180]
>>> y_train=y_digits[: -180]
>>> X_test=X_digits[-180 :]
>>> y_test=y_digits[-180 :]
>>> logisitic=linear_model.LogisticRegression()
logisitic.fit(X_train,y_train)
logisitic.predict(X_test)
 dif=(logisitic.predict(X_test)-y_test)
  c=0
   for i in range(dif.size):
...  if dif[i]!=0:
...   c=c+1

 knn=neighbors.KNeighborsClassifier()
>>> knn.fit(X_train,y_train)
d=0
 diff=knn.predict(X_test)-y_test
>>> for i in range(diff.size):
...  if diff[i]!=0:
...   d=d+1